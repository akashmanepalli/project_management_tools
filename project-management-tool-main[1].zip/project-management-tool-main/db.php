<?php
$con = mysqli_connect("localhost", "root", "2507", "pms_project");
if (!$con) {
    die("not connected");
}
?>